def receive():
    print('这是接受的文件')